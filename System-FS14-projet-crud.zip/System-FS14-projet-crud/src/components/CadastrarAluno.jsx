import React from 'react'
import {  Table, Button, Form } from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';

 class CadastrarAluno extends React.Component{

  constructor(props){
    super(props);

    this.state = {
      alunos: [
        {'id': 0, 'nome': '', 'email': ''},
      ]
      
    }
  }

  componentDidMount(){
   this.buscarAluno()
  }
  componentWillUnmount(){
    
  }
  // buscar alunos
  buscarAluno=()=>{
    fetch("https://64e7ab01b0fd9648b7903ce3.mockapi.io/teste")
    .then(resposta => resposta.json())
    .then(dados =>{
      this.setState({alunos: dados})
    })
  }
  // função deletar
  deleteAlunos=(id)=>{
    fetch("https://64e7ab01b0fd9648b7903ce3.mockapi.io/teste/"+id, { method: 'DELETE'})
    .then(resposta =>{
      if(resposta.ok){
        this.buscarAluno()
      }
    })
  }
  // botao atualizar....
  carregarDados=(id)=>{
    fetch("https://64e7ab01b0fd9648b7903ce3.mockapi.io/teste/"+id, { method: 'GET'})
    .then(resposta => resposta.json())
    .then(aluno =>{
      this.setState({
          id: aluno.id,
          nome: aluno.nome,
          email: aluno.email
      })
    })
  }
  // botão adicionar..
  cadastroAluno = (aluno)=>{
    fetch("https://64e7ab01b0fd9648b7903ce3.mockapi.io/teste",
        { method: 'POST',
            headers: {'Content-Type':'application/json'},
             body: JSON.stringify(aluno)
         } )
      .then(resposta =>{
        if(resposta.ok){
          this.buscarAluno();
      }else{
        alert('não foi possível adicionar o aluno');
      }
    })
  }
    // atualizar aluno...
  atualizarAluno = (aluno)=>{
    fetch("https://64e7ab01b0fd9648b7903ce3.mockapi.io/teste"+aluno.id,
        { method: 'PUT',
            headers: {'Content-Type':'application/json'},
             body: JSON.stringify(aluno)
         } )
            .then(resposta =>{
              if(resposta.ok){
                this.buscarAluno();
            }else{
              alert('não foi possível atualizar os dados do aluno');
            }
    })
  }

  renderTabela(){

    return <Table striped bordered hover>
                  <thead>
                      <tr>
                        <th>nome</th>
                        <th>email</th>
                        <th>opções</th>
                      </tr>
                    </thead>
                    <tbody>
                          {
                            this.state.alunos.map((aluno) =>(
                              <tr key={aluno}>
                                  <th>{aluno.nome}</th>
                                  <th>{aluno.email}</th>
                                  <th>
                                  <Button variant="warning" onClick={() => this.carregarDados(aluno.id)}>Atualizar</Button>
                                  <Button variant="danger" onClick={() => this.deleteAlunos(aluno.id)}>Excluir</Button>
                                  </th>
                              </tr>
                            ))
                          }
                    
                    </tbody>
          </Table>
  }
// setar o nome no form -> nome...
    atualizaNome=(e)=>{
      this.setState.aluno(
        {nome: e.target.value}
      )
    }
  // setar o emial no form -> email...
    atualizaEmail=(e)=>{
      this.setState.aluno(
        {email: e.target.value}
      )
    }

 // butão de cadastrar -> adicionar
    submmit=()=>{
      
          const aluno= {
            
                 alunos : [
                      {
                        nome: this.state.nome,
                        email: this.state.email
                      }
                ]
           }
           this.cadastroAluno(aluno);  
    }


  render(){
    return(
      <div>
              <Form>
                  <Form.Group className="mb-3" >
                      <Form.Label>ID</Form.Label>
                      <Form.Control type="text" value={this.state.id} readOnly={true}/>
                  </Form.Group>
                  <Form.Group className="mb-3" >
                      <Form.Label>Nome</Form.Label>
                      <Form.Control type="text" placeholder="Nome do aluno" value={this.state.nome} onChange={this.atualizaNome}/>
                  </Form.Group>
                  <Form.Group className="mb-3" >
                      <Form.Label>E-mail</Form.Label>
                      <Form.Control type="text" placeholder="E-mail do aluno" value={this.state.email} onChange={this.atualizaEmail}/>
                  </Form.Group>
                  <Button variant="primary" type="submit" onClick={this.submmit}>
                     Adicionar
                  </Button>
              </Form>
           {this.renderTabela()}
      </div>
    )
  }
  
}

export default CadastrarAluno;

