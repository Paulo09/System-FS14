import React from 'react'
import CadastrarAluno from '../components/CadastrarAluno'



export const Usuario = () => {
  return (
    <div>
      <h1>cadastro de alunos</h1>
      <CadastrarAluno/>
      
    </div>
  )
}
