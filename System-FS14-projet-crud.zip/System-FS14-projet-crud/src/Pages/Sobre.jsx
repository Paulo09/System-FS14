import React from 'react'

export const Sobre = () => {
  return (
    <div>
     <h1>USUÁRIOS</h1>
      <p>Essa é página de usuários</p>
    </div>
  )
}
