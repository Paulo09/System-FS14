import React from 'react'

export const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>Essa é a home</p>
    </div>
  )
}
