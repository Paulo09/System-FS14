
import { BrowserRouter, Routes, Link, Route } from 'react-router-dom'
import { Nav } from 'react-bootstrap'
import { Home } from './Pages/Home';
import { Usuario } from './Pages/Usuario';
import { Sobre } from './Pages/Sobre';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  

  return (
    <>
        <BrowserRouter>
          <Nav variant='tabs'>
            <Nav.Link as={Link} to='/'>pagina inicial</Nav.Link>
            <Nav.Link as={Link} to='/usuario'>usuario</Nav.Link>
            <Nav.Link as={Link} to='/sobre'>sobre</Nav.Link>
          </Nav>
          <Routes>
            <Route path='/' index element={<Home/>}/>
            <Route path='/usuario' element={<Usuario/>}/>
            <Route path='/sobre' element={<Sobre/>} />
          </Routes>
        </BrowserRouter>
    </>
  )
}

export default App
